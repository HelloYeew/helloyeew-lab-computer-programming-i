from player import *
ann = Player('Ann', 2, 4)
bob = Player('Bob', 3, 5)
print(ann)
print(bob)
ann.randomize_hand()
print(ann)
bob.randomize_hand()
print(bob)