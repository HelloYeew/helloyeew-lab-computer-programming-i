from board import *
board = Board('board1.txt')
print(board.length)
print(board.width)
print(board)